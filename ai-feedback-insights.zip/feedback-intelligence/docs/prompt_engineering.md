# Extraction Prompt Engineering Reference

This document explains the prompt design choices in `utils/extractor.py`.

---

## System Prompt Design

```
You are an expert customer intelligence analyst specialising in B2B SaaS.
Your task is to extract structured operational intelligence from customer interview transcripts.

You must return ONLY valid JSON — no markdown fences, no preamble, no commentary.
Follow the schema exactly. If a field has no data, use an empty list [] or null.

Focus on:
- Concrete, specific pain points (not vague dissatisfaction)
- Actionable feature requests with clear product implications
- Genuine churn signals (contract risk, competitor evaluation, frustration)
- Next-step action items that a CSM or PM would actually take
- Competitors named or implied
- Overall tone and emotional temperature of the conversation
```

### Why this works

**Role framing**: Anchoring the model as a "customer intelligence analyst" shifts output toward operational language — CSM-speak, product terminology, business context — rather than generic summarisation.

**Output constraint**: Requiring "ONLY valid JSON" with explicit prohibition of markdown fences eliminates the most common cause of parse failures. The model is reminded not to be helpful in ways that break downstream processing.

**Specificity guidance**: "Concrete, specific pain points (not vague dissatisfaction)" significantly improves signal quality. Without this, models tend toward vague extractions like "customer seemed frustrated" rather than "API latency spikes cause batch job failures requiring manual restart."

---

## Extraction Prompt Design

### Churn risk calibration

The `churn_risk.score` is a float from 0.0–1.0. Calibration guidance (implicit in the schema + examples):

| Score range | Signal |
|---|---|
| 0.0–0.3 | No churn signals; customer is stable or growing |
| 0.3–0.5 | Minor frustration; monitoring recommended |
| 0.5–0.7 | Active concern; follow-up required |
| 0.7–0.85 | High risk; competitor evaluation or explicit conditions |
| 0.85–1.0 | Critical; departure likely without immediate intervention |

### Sentiment score calibration

`sentiment.score` is -1.0 to +1.0:
- +1.0 = enthusiastic advocacy
- 0.0 = neutral / factual
- -1.0 = angry or deeply frustrated

The `label` field handles the categorical case; `score` captures nuance within categories (e.g. "Mixed" at -0.1 vs "Mixed" at +0.4 tells a different story).

### Owner assignment logic

The model assigns action item owners based on the nature of the task:

| Owner | When to use |
|---|---|
| CSM | Relationship actions, follow-up calls, account check-ins |
| PM | Feature requests, roadmap questions, product feedback routing |
| Engineering | Technical issues, bug reports, performance investigations |
| Sales | Contract, pricing, renewal, upsell conversations |
| Leadership | Escalations, strategic accounts, high-churn-risk decisions |

---

## Temperature Choice

`temperature=0.2` is deliberate. This is a structured data extraction task, not a creative one. Lower temperature:
- Produces more consistent field populations across different transcripts
- Reduces hallucinated quotes or invented severity scores
- Makes the JSON output more reliably parseable

For the `executive_summary` field, slightly higher temperature (0.4–0.6) could produce more vivid prose, but the consistency tradeoff isn't worth it for a production system.

---

## Prompt Variations to Try

### For sales call transcripts
Add to the system prompt:
```
Pay special attention to: budget signals, decision-making authority, timeline for decision, 
objections raised, and next steps agreed on the call. The output should be useful for a 
sales manager doing call review.
```

### For support tickets (text-based)
Add to the system prompt:
```
This is a support interaction, not an interview. Focus on: issue category, resolution status,
customer frustration level, and whether this indicates a product gap vs user error.
```

### For NPS survey comments
Add to the system prompt:
```
This is a short-form survey response, not a transcript. Extract what you can from limited context.
Be conservative with churn risk scores — absence of signal is not the same as no risk.
```

---

## Handling Difficult Transcripts

### Very short transcripts (< 500 words)
The model will extract less but won't hallucinate. Empty arrays are valid output.

### Multi-speaker transcripts without clear labels
The extraction prompt handles this gracefully — it focuses on *what was said*, not *who said it*.

### Transcripts in languages other than English
GPT-4o handles multilingual input well. The output JSON will still be in English. No prompt changes needed.

### Transcripts with heavy redaction or PII removal
Performance degrades proportionally to the information removed. Consider running extraction before redaction and storing only the structured output.
