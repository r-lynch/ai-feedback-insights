"""
Insight extractor — calls OpenAI and returns structured feedback intelligence.
"""

import json
import re
from openai import OpenAI

SYSTEM_PROMPT = """
You are an expert customer intelligence analyst specialising in B2B SaaS.
Your task is to extract structured operational intelligence from customer interview transcripts.

You must return ONLY valid JSON — no markdown fences, no preamble, no commentary.
Follow the schema exactly. If a field has no data, use an empty list [] or null.

Focus on:
- Concrete, specific pain points (not vague dissatisfaction)
- Actionable feature requests with clear product implications
- Genuine churn signals (contract risk, competitor evaluation, frustration)
- Next-step action items that a CSM or PM would actually take
- Competitors named or implied
- Overall tone and emotional temperature of the conversation
"""

EXTRACTION_PROMPT = """
Analyse the following customer interview transcript and extract structured intelligence.

Return a JSON object with this exact structure:

{
  "pain_points": [
    {
      "description": "Specific pain point description",
      "severity": "high|medium|low",
      "category": "Product|Pricing|Support|Onboarding|Integration|Performance|Other",
      "quote": "Direct quote from transcript if available, else null"
    }
  ],
  "feature_requests": [
    {
      "description": "Clear feature or capability request",
      "priority": "high|medium|low",
      "area": "API|Dashboard|Integrations|Audio Quality|Pricing|Other",
      "quote": "Direct quote if available, else null"
    }
  ],
  "sentiment": {
    "label": "Positive|Negative|Neutral|Mixed",
    "score": 0.0,
    "summary": "2-3 sentence emotional and tonal summary of the conversation"
  },
  "churn_risk": {
    "score": 0.0,
    "level": "Low|Medium|High|Critical",
    "reasoning": "Explanation of churn risk signals found in transcript"
  },
  "action_items": [
    {
      "task": "Specific, actionable next step",
      "owner": "CSM|PM|Engineering|Sales|Leadership",
      "urgency": "high|normal|low"
    }
  ],
  "competitors_mentioned": [
    {
      "name": "Competitor name",
      "context": "How they were mentioned (evaluating, switched from, comparing)",
      "sentiment": "Customer's apparent sentiment toward this competitor"
    }
  ],
  "executive_summary": "3-4 sentence summary of the most important takeaways from this conversation, framed for a VP of Customer Success or CPO.",
  "customer_name": "Customer or company name if mentioned, else null",
  "key_themes": ["theme1", "theme2", "theme3"]
}

TRANSCRIPT:
{transcript}
"""


def extract_insights(transcript: str, api_key: str, model: str = "gpt-4o") -> dict:
    """
    Extract structured insights from a customer interview transcript.
    Returns a dict conforming to the extraction schema.
    """
    client = OpenAI(api_key=api_key)

    prompt = EXTRACTION_PROMPT.format(transcript=transcript)

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user",   "content": prompt},
        ],
        temperature=0.2,  # Low temperature for consistent structured output
        max_tokens=2500,
    )

    raw = response.choices[0].message.content.strip()

    # Strip any accidental markdown fences
    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)

    try:
        insights = json.loads(raw)
    except json.JSONDecodeError as e:
        # Fallback: return minimal structure with error note
        insights = {
            "pain_points": [],
            "feature_requests": [],
            "sentiment": {"label": "Unknown", "score": 0.0, "summary": f"Extraction failed: {e}"},
            "churn_risk": {"score": 0.0, "level": "Unknown", "reasoning": "Extraction failed"},
            "action_items": [],
            "competitors_mentioned": [],
            "executive_summary": f"Extraction error: {e}. Raw output: {raw[:500]}",
            "customer_name": None,
            "key_themes": [],
        }

    return insights
