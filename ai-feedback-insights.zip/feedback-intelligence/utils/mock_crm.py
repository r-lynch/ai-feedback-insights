"""
Simulates a Salesforce/HubSpot CRM push.
In production, replace with actual Salesforce REST API or HubSpot client.
"""

from datetime import datetime
import hashlib
import time


def generate_mock_crm_sync(crm_record: dict) -> dict:
    """
    Simulate syncing a CRM record to Salesforce.
    Returns a mock API response that mirrors Salesforce's REST API format.
    """

    # Simulate API latency
    time.sleep(0.5)

    record_id = crm_record.get("record_id", "UNKNOWN")
    sf_id = "001" + hashlib.md5(record_id.encode()).hexdigest()[:15].upper()

    return {
        "success": True,
        "id":      sf_id,
        "errors":  [],
        "created": True,
        "object":  "CustomerFeedback__c",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "fields_written": [
            "Account_Name__c",
            "Interview_Date__c",
            "Overall_Sentiment__c",
            "Churn_Risk_Level__c",
            "Churn_Risk_Score__c",
            "Pain_Point_Count__c",
            "Feature_Request_Count__c",
            "Action_Item_Count__c",
            "Executive_Summary__c",
            "Priority_Follow_Up__c",
            "Competitors_Mentioned__c",
        ],
        "mock": True,
        "note": "This is a simulated sync. Wire up Salesforce REST API credentials to enable live pushes.",
    }
