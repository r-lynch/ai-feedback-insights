"""
Aggregates multiple insight records to surface recurring themes,
top feature requests, and cross-interview patterns.
"""

from collections import Counter
from typing import List


def analyze_themes(records: List[dict]) -> dict:
    """
    Given a list of insight records, compute:
    - Top recurring themes
    - Top feature requests
    - Pain point categories
    - Competitor frequency
    """

    all_themes:    list = []
    all_features:  list = []
    all_categories: list = []
    all_competitors: list = []

    for r in records:
        # Key themes
        for t in r.get("key_themes", []):
            all_themes.append(t.strip().lower())

        # Pain categories
        for p in r.get("pain_points", []):
            cat = p.get("category", "Other")
            all_categories.append(cat)

        # Feature requests (keep full objects, deduplicate by description)
        for f in r.get("feature_requests", []):
            all_features.append(f)

        # Competitors
        for c in r.get("competitors_mentioned", []):
            all_competitors.append(c.get("name", "Unknown"))

    # Count themes
    theme_counter = Counter(all_themes)
    total_records = max(len(records), 1)

    top_themes = [
        {
            "name":      theme,
            "count":     count,
            "frequency": round(count / total_records, 2),
        }
        for theme, count in theme_counter.most_common(8)
    ]

    # Deduplicate & rank feature requests by priority
    priority_order = {"high": 0, "medium": 1, "low": 2}
    seen_features: set = set()
    deduped_features: list = []
    for f in sorted(all_features, key=lambda x: priority_order.get(x.get("priority", "low"), 2)):
        desc_key = f.get("description", "")[:60].lower()
        if desc_key not in seen_features:
            seen_features.add(desc_key)
            deduped_features.append(f)

    top_features = deduped_features[:6]

    # Category breakdown
    category_counter = Counter(all_categories)
    pain_categories = [
        {"category": cat, "count": count}
        for cat, count in category_counter.most_common()
    ]

    # Competitor frequency
    competitor_counter = Counter(all_competitors)
    competitor_frequency = [
        {"name": name, "count": count}
        for name, count in competitor_counter.most_common(5)
    ]

    return {
        "top_themes":           top_themes,
        "top_features":         top_features,
        "pain_categories":      pain_categories,
        "competitor_frequency": competitor_frequency,
        "total_interviews":     total_records,
    }
