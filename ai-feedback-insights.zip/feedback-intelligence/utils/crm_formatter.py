"""
Converts raw insight dicts into flattened CRM-compatible records.
Mirrors common Salesforce / HubSpot field conventions.
"""

from datetime import datetime


def format_crm_record(insights: dict, metadata: dict) -> dict:
    """
    Flatten the rich insight object into a CRM-ready record.
    Fields are named to match common Salesforce custom object conventions.
    """

    pain_points       = insights.get("pain_points", [])
    feature_requests  = insights.get("feature_requests", [])
    action_items      = insights.get("action_items", [])
    competitors       = insights.get("competitors_mentioned", [])
    sentiment         = insights.get("sentiment", {})
    churn             = insights.get("churn_risk", {})

    # Derive high-severity signals
    high_pains    = [p for p in pain_points       if p.get("severity")  == "high"]
    high_features = [f for f in feature_requests  if f.get("priority")  == "high"]
    urgent_actions = [a for a in action_items     if a.get("urgency")   == "high"]

    requires_priority_followup = (
        churn.get("score", 0) > 0.6 or len(high_pains) >= 2 or len(urgent_actions) > 0
    )

    record = {
        # ── Identity
        "record_id":         _generate_id(metadata),
        "record_created_at": datetime.utcnow().isoformat() + "Z",
        "account_name":      metadata.get("customer_name", "Unknown"),
        "interview_date":    metadata.get("interview_date", ""),
        "interviewer":       metadata.get("interviewer", ""),
        "segment":           metadata.get("segment", "Unknown"),
        "primary_use_case":  metadata.get("use_case", "Unknown"),

        # ── Sentiment
        "overall_sentiment":       sentiment.get("label", "Unknown"),
        "sentiment_score":         round(sentiment.get("score", 0.0), 3),
        "sentiment_summary":       sentiment.get("summary", ""),

        # ── Churn
        "churn_risk_score":        round(churn.get("score", 0.0), 3),
        "churn_risk_level":        churn.get("level", "Unknown"),
        "churn_risk_reasoning":    churn.get("reasoning", ""),
        "requires_priority_followup": requires_priority_followup,

        # ── Counts
        "pain_point_count":        len(pain_points),
        "high_severity_pain_count": len(high_pains),
        "feature_request_count":   len(feature_requests),
        "high_priority_feature_count": len(high_features),
        "action_item_count":       len(action_items),
        "competitor_count":        len(competitors),

        # ── Structured lists (stored as JSON strings in real CRM)
        "pain_points_json":         pain_points,
        "feature_requests_json":    feature_requests,
        "action_items_json":        action_items,
        "competitors_json":         competitors,

        # ── Flattened top items (for CRM field display)
        "top_pain_point":      high_pains[0]["description"] if high_pains else (pain_points[0]["description"] if pain_points else ""),
        "top_feature_request": high_features[0]["description"] if high_features else (feature_requests[0]["description"] if feature_requests else ""),
        "top_action_item":     urgent_actions[0]["task"] if urgent_actions else (action_items[0]["task"] if action_items else ""),
        "competitors_list":    ", ".join(c["name"] for c in competitors) if competitors else "",

        # ── Summary
        "executive_summary":   insights.get("executive_summary", ""),
        "key_themes":          insights.get("key_themes", []),
    }

    return record


def _generate_id(metadata: dict) -> str:
    import hashlib, time
    raw = f"{metadata.get('customer_name','')}-{metadata.get('interview_date','')}-{time.time()}"
    return "FB-" + hashlib.md5(raw.encode()).hexdigest()[:8].upper()
