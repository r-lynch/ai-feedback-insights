"""
AI Customer Feedback Intelligence Pipeline
ElevenLabs — Impact Strategy & Operations Demo
"""

import streamlit as st
import json
import time
from pathlib import Path
import sys

sys.path.append(str(Path(__file__).parent.parent))

from utils.extractor import extract_insights
from utils.crm_formatter import format_crm_record
from utils.theme_analyzer import analyze_themes
from utils.mock_crm import generate_mock_crm_sync

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Feedback Intelligence | ElevenLabs",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;500;600&display=swap');

  html, body, [class*="css"] {
    font-family: 'IBM Plex Sans', sans-serif;
  }

  .main { background: #0a0a0f; }
  .stApp { background: #0a0a0f; }

  /* Sidebar */
  section[data-testid="stSidebar"] {
    background: #0f0f1a;
    border-right: 1px solid #1e1e2e;
  }

  /* Cards */
  .insight-card {
    background: #111120;
    border: 1px solid #1e1e35;
    border-radius: 8px;
    padding: 1.2rem 1.4rem;
    margin-bottom: 0.75rem;
    position: relative;
  }

  .insight-card::before {
    content: '';
    position: absolute;
    left: 0; top: 0; bottom: 0;
    width: 3px;
    border-radius: 8px 0 0 8px;
  }

  .card-pain::before    { background: #ef4444; }
  .card-feature::before { background: #3b82f6; }
  .card-churn::before   { background: #f59e0b; }
  .card-action::before  { background: #10b981; }
  .card-competitor::before { background: #8b5cf6; }

  .badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 0.7rem;
    font-family: 'IBM Plex Mono', monospace;
    font-weight: 600;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    margin-right: 6px;
    margin-bottom: 6px;
  }

  .badge-red    { background: rgba(239,68,68,0.15);  color: #ef4444; border: 1px solid rgba(239,68,68,0.3); }
  .badge-blue   { background: rgba(59,130,246,0.15); color: #60a5fa; border: 1px solid rgba(59,130,246,0.3); }
  .badge-amber  { background: rgba(245,158,11,0.15); color: #fbbf24; border: 1px solid rgba(245,158,11,0.3); }
  .badge-green  { background: rgba(16,185,129,0.15); color: #34d399; border: 1px solid rgba(16,185,129,0.3); }
  .badge-purple { background: rgba(139,92,246,0.15); color: #a78bfa; border: 1px solid rgba(139,92,246,0.3); }
  .badge-gray   { background: rgba(156,163,175,0.1); color: #9ca3af; border: 1px solid rgba(156,163,175,0.2); }

  .metric-block {
    background: #111120;
    border: 1px solid #1e1e35;
    border-radius: 8px;
    padding: 1.2rem;
    text-align: center;
  }

  .metric-number {
    font-size: 2.2rem;
    font-weight: 600;
    font-family: 'IBM Plex Mono', monospace;
    line-height: 1;
    margin-bottom: 4px;
  }

  .metric-label {
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #6b7280;
    font-family: 'IBM Plex Mono', monospace;
  }

  .section-header {
    font-size: 0.7rem;
    font-family: 'IBM Plex Mono', monospace;
    text-transform: uppercase;
    letter-spacing: 0.12em;
    color: #4b5563;
    margin-bottom: 0.75rem;
    padding-bottom: 0.5rem;
    border-bottom: 1px solid #1e1e35;
  }

  .crm-block {
    background: #0d0d1a;
    border: 1px solid #1e1e35;
    border-radius: 6px;
    padding: 1rem;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.78rem;
    color: #a0aec0;
    white-space: pre-wrap;
    overflow-x: auto;
  }

  .hero-title {
    font-size: 1.6rem;
    font-weight: 600;
    color: #f1f5f9;
    letter-spacing: -0.02em;
    line-height: 1.2;
  }

  .hero-sub {
    font-size: 0.85rem;
    color: #6b7280;
    margin-top: 4px;
    font-family: 'IBM Plex Mono', monospace;
  }

  .sentiment-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 14px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 500;
  }

  .churn-bar-container {
    background: #1e1e35;
    border-radius: 4px;
    height: 6px;
    margin-top: 8px;
    overflow: hidden;
  }
  .churn-bar-fill {
    height: 100%;
    border-radius: 4px;
    transition: width 1s ease;
  }

  hr { border-color: #1e1e35; }

  /* Streamlit widget overrides */
  .stTextArea textarea {
    background: #111120 !important;
    border-color: #1e1e35 !important;
    color: #e2e8f0 !important;
    font-family: 'IBM Plex Mono', monospace !important;
    font-size: 0.82rem !important;
  }

  .stButton > button {
    background: #2563eb !important;
    color: white !important;
    border: none !important;
    border-radius: 6px !important;
    font-family: 'IBM Plex Sans', sans-serif !important;
    font-weight: 500 !important;
    padding: 0.5rem 1.4rem !important;
    transition: all 0.2s !important;
  }

  .stButton > button:hover {
    background: #1d4ed8 !important;
    transform: translateY(-1px) !important;
  }

  div[data-testid="stFileUploader"] {
    background: #111120 !important;
    border: 1px dashed #2d2d50 !important;
    border-radius: 8px !important;
  }

  .stSelectbox > div > div {
    background: #111120 !important;
    border-color: #1e1e35 !important;
    color: #e2e8f0 !important;
  }

  .stTabs [data-baseweb="tab-list"] {
    background: transparent;
    gap: 4px;
  }

  .stTabs [data-baseweb="tab"] {
    background: #111120;
    border: 1px solid #1e1e35;
    border-radius: 6px;
    color: #6b7280;
    font-size: 0.8rem;
    font-family: 'IBM Plex Mono', monospace;
  }

  .stTabs [aria-selected="true"] {
    background: #1e1e40 !important;
    color: #93c5fd !important;
    border-color: #3b82f6 !important;
  }

  p, li { color: #cbd5e1; }
  h1, h2, h3 { color: #f1f5f9; }

  .stExpander {
    background: #111120 !important;
    border: 1px solid #1e1e35 !important;
    border-radius: 8px !important;
  }
</style>
""", unsafe_allow_html=True)


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style='padding: 0.5rem 0 1.5rem 0;'>
      <div style='font-family: IBM Plex Mono, monospace; font-size: 0.65rem; 
                  color: #4b5563; text-transform: uppercase; letter-spacing: 0.1em; 
                  margin-bottom: 8px;'>ElevenLabs · Impact Ops</div>
      <div style='font-size: 1.1rem; font-weight: 600; color: #f1f5f9; 
                  letter-spacing: -0.02em;'>Feedback Intelligence</div>
      <div style='font-family: IBM Plex Mono, monospace; font-size: 0.7rem; 
                  color: #3b82f6; margin-top: 4px;'>v1.0 · Pipeline</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<div class="section-header">Configuration</div>', unsafe_allow_html=True)

    api_key = st.text_input(
        "OpenAI API Key",
        type="password",
        placeholder="sk-...",
        help="Your key stays local — never stored or transmitted beyond your session."
    )

    model_choice = st.selectbox(
        "Model",
        ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo"],
        index=0,
        help="gpt-4o recommended for highest extraction accuracy"
    )

    st.markdown('<div class="section-header" style="margin-top:1.5rem;">Sample Data</div>', unsafe_allow_html=True)

    sample_dir = Path(__file__).parent.parent / "data" / "sample_transcripts"
    sample_files = list(sample_dir.glob("*.txt")) if sample_dir.exists() else []
    sample_names = ["— select —"] + [f.stem.replace("_", " ").title() for f in sample_files]

    selected_sample = st.selectbox("Load sample transcript", sample_names)

    st.markdown("---")
    st.markdown("""
    <div style='font-family: IBM Plex Mono, monospace; font-size: 0.65rem; color: #374151; line-height: 1.6;'>
    Upload a transcript → AI extracts structured insights → CRM record generated → Dashboard updated
    <br><br>
    Supports: .txt, .pdf (text), .md, or paste directly
    </div>
    """, unsafe_allow_html=True)


# ── Main Layout ───────────────────────────────────────────────────────────────
st.markdown("""
<div style='padding: 0.5rem 0 2rem 0; border-bottom: 1px solid #1e1e35; margin-bottom: 2rem;'>
  <div class='hero-title'>Customer Feedback Intelligence Pipeline</div>
  <div class='hero-sub'>Qualitative conversations → Structured product & revenue signals</div>
</div>
""", unsafe_allow_html=True)

tabs = st.tabs(["⬆  Ingest", "🔬  Insights", "📋  CRM Record", "📊  Dashboard", "⚙️  Export"])

# ─────────────────────────────────────────────────────────────────────────────
# TAB 1 — INGEST
# ─────────────────────────────────────────────────────────────────────────────
with tabs[0]:
    col_left, col_right = st.columns([3, 2], gap="large")

    with col_left:
        st.markdown('<div class="section-header">Transcript Input</div>', unsafe_allow_html=True)

        uploaded_file = st.file_uploader(
            "Drop a transcript file here",
            type=["txt", "md", "pdf"],
            help="Plain text transcripts work best. PDF support extracts text layer."
        )

        transcript_text = st.text_area(
            "Or paste transcript directly",
            height=320,
            placeholder="[00:00] Interviewer: Thanks for joining today...\n[00:05] Customer: Happy to be here...",
        )

        # Load sample if selected
        if selected_sample != "— select —" and sample_files:
            idx = sample_names.index(selected_sample) - 1
            loaded = sample_files[idx].read_text(encoding="utf-8")
            transcript_text = loaded
            st.info(f"✓ Sample loaded: **{selected_sample}**")

        # Handle file upload
        if uploaded_file:
            if uploaded_file.type == "application/pdf":
                try:
                    import pdfplumber
                    with pdfplumber.open(uploaded_file) as pdf:
                        transcript_text = "\n".join(p.extract_text() or "" for p in pdf.pages)
                    st.success(f"✓ PDF parsed — {len(transcript_text)} characters extracted")
                except ImportError:
                    transcript_text = uploaded_file.read().decode("utf-8", errors="ignore")
            else:
                transcript_text = uploaded_file.read().decode("utf-8", errors="ignore")
            st.success(f"✓ File loaded — {len(transcript_text):,} characters")

        # Store in session
        if transcript_text:
            st.session_state["transcript"] = transcript_text

    with col_right:
        st.markdown('<div class="section-header">Metadata</div>', unsafe_allow_html=True)

        customer_name  = st.text_input("Customer / Account name", placeholder="Acme Corp")
        interview_date = st.date_input("Interview date")
        interviewer    = st.text_input("Interviewer", placeholder="Your name")
        segment        = st.selectbox("Segment", ["Enterprise", "Mid-Market", "SMB", "Startup", "Unknown"])
        use_case       = st.text_input("Primary use case / product area", placeholder="e.g. API voice synthesis")
        notes          = st.text_area("Pre-call notes (optional)", height=80, placeholder="Known pain points, renewal coming up, etc.")

        st.session_state["metadata"] = {
            "customer_name":  customer_name or "Unknown",
            "interview_date": str(interview_date),
            "interviewer":    interviewer or "Unknown",
            "segment":        segment,
            "use_case":       use_case or "Unknown",
            "notes":          notes,
        }

    st.markdown("---")
    run_col, _ = st.columns([2, 5])
    with run_col:
        run_pipeline = st.button("🚀  Run Intelligence Pipeline", use_container_width=True)

    if run_pipeline:
        transcript = st.session_state.get("transcript", "")
        if not transcript.strip():
            st.error("Please provide a transcript before running.")
        elif not api_key:
            st.warning("Add your OpenAI API key in the sidebar to run live extraction. Showing demo output.")
            # Load demo output
            demo_path = Path(__file__).parent.parent / "data" / "demo_output.json"
            if demo_path.exists():
                st.session_state["insights"] = json.loads(demo_path.read_text())
                st.session_state["crm_record"] = format_crm_record(
                    st.session_state["insights"], st.session_state["metadata"]
                )
                st.success("✓ Demo insights loaded — navigate to the Insights tab")
            else:
                st.error("No demo output found. Please add an API key.")
        else:
            with st.spinner("Extracting intelligence from transcript…"):
                progress = st.progress(0)
                status   = st.empty()

                status.markdown("_Parsing transcript structure…_")
                time.sleep(0.5)
                progress.progress(20)

                status.markdown("_Running sentiment and churn analysis…_")
                time.sleep(0.3)
                progress.progress(40)

                status.markdown("_Extracting pain points and feature signals…_")
                insights = extract_insights(transcript, api_key, model_choice)
                progress.progress(75)

                status.markdown("_Generating CRM record…_")
                crm_record = format_crm_record(insights, st.session_state["metadata"])
                progress.progress(90)

                status.markdown("_Finalising dashboard data…_")
                time.sleep(0.3)
                progress.progress(100)
                status.empty()

                st.session_state["insights"]   = insights
                st.session_state["crm_record"] = crm_record

            st.success("✓ Pipeline complete — navigate to the **Insights** tab")


# ─────────────────────────────────────────────────────────────────────────────
# TAB 2 — INSIGHTS
# ─────────────────────────────────────────────────────────────────────────────
with tabs[1]:
    insights = st.session_state.get("insights")

    if not insights:
        st.info("Run the pipeline on the **Ingest** tab to see extracted insights here.")
        # Show schema preview
        st.markdown('<div class="section-header" style="margin-top:1rem;">Extraction Schema</div>', unsafe_allow_html=True)
        schema_path = Path(__file__).parent.parent / "data" / "extraction_schema.json"
        if schema_path.exists():
            st.json(json.loads(schema_path.read_text()))
    else:
        # ── Top metrics ──
        sentiment     = insights.get("sentiment", {})
        churn_score   = insights.get("churn_risk", {}).get("score", 0)
        pain_count    = len(insights.get("pain_points", []))
        feat_count    = len(insights.get("feature_requests", []))
        action_count  = len(insights.get("action_items", []))
        comp_count    = len(insights.get("competitors_mentioned", []))

        sentiment_label = sentiment.get("label", "Neutral")
        sentiment_score = sentiment.get("score", 0)

        sent_color = {"Positive": "#10b981", "Neutral": "#6b7280", "Negative": "#ef4444",
                      "Mixed": "#f59e0b"}.get(sentiment_label, "#6b7280")

        churn_color = "#10b981" if churn_score < 0.4 else ("#f59e0b" if churn_score < 0.7 else "#ef4444")

        c1, c2, c3, c4, c5 = st.columns(5)
        for col, num, label, color in [
            (c1, pain_count,   "Pain Points",       "#ef4444"),
            (c2, feat_count,   "Feature Requests",  "#3b82f6"),
            (c3, action_count, "Action Items",       "#10b981"),
            (c4, comp_count,   "Competitors",        "#8b5cf6"),
            (c5, f"{int(churn_score*100)}%", "Churn Risk",  churn_color),
        ]:
            with col:
                st.markdown(f"""
                <div class="metric-block">
                  <div class="metric-number" style="color:{color};">{num}</div>
                  <div class="metric-label">{label}</div>
                </div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        col_a, col_b = st.columns(2, gap="large")

        with col_a:
            # Pain points
            st.markdown('<div class="section-header">Pain Points</div>', unsafe_allow_html=True)
            for p in insights.get("pain_points", []):
                severity = p.get("severity", "medium").capitalize()
                sev_cls  = {"High": "badge-red", "Medium": "badge-amber", "Low": "badge-green"}.get(severity, "badge-gray")
                st.markdown(f"""
                <div class="insight-card card-pain">
                  <span class="badge {sev_cls}">{severity}</span>
                  <span class="badge badge-gray">{p.get('category','')}</span>
                  <div style="margin-top:8px; color:#e2e8f0; font-size:0.88rem;">{p.get('description','')}</div>
                  {f'<div style="margin-top:6px; font-size:0.75rem; color:#6b7280; font-style:italic;">"{p.get("quote","")}"</div>' if p.get('quote') else ''}
                </div>""", unsafe_allow_html=True)

            # Competitors
            comps = insights.get("competitors_mentioned", [])
            if comps:
                st.markdown('<div class="section-header" style="margin-top:1.5rem;">Competitors Mentioned</div>', unsafe_allow_html=True)
                for c in comps:
                    st.markdown(f"""
                    <div class="insight-card card-competitor">
                      <span class="badge badge-purple">{c.get('name','')}</span>
                      <span class="badge badge-gray">{c.get('context','')}</span>
                      <div style="margin-top:8px; color:#e2e8f0; font-size:0.85rem;">{c.get('sentiment','')}</div>
                    </div>""", unsafe_allow_html=True)

        with col_b:
            # Feature requests
            st.markdown('<div class="section-header">Feature Requests</div>', unsafe_allow_html=True)
            for f in insights.get("feature_requests", []):
                priority = f.get("priority", "medium").capitalize()
                pri_cls  = {"High": "badge-red", "Medium": "badge-blue", "Low": "badge-gray"}.get(priority, "badge-gray")
                pri_num  = {"High": "1", "Medium": "2", "Low": "3"}.get(priority, "2")
                quote_html = f'<div style="margin-top:6px; font-size:0.75rem; color:#6b7280; font-style:italic;">"{f.get("quote","")}"</div>' if f.get('quote') else ''
                st.markdown(f"""
                <div class="insight-card card-feature">
                  <span class="badge {pri_cls}">P{pri_num}</span>
                  <span class="badge badge-gray">{f.get('area','')}</span>
                  <div style="margin-top:8px; color:#e2e8f0; font-size:0.88rem;">{f.get('description','')}</div>
                  {quote_html}
                </div>""", unsafe_allow_html=True)

            # Action items
            st.markdown('<div class="section-header" style="margin-top:1.5rem;">Action Items</div>', unsafe_allow_html=True)
            for a in insights.get("action_items", []):
                owner  = a.get("owner", "team")
                urgency = a.get("urgency", "normal").capitalize()
                urg_cls = {"High": "badge-red", "Normal": "badge-blue", "Low": "badge-gray"}.get(urgency, "badge-gray")
                st.markdown(f"""
                <div class="insight-card card-action">
                  <span class="badge {urg_cls}">{urgency}</span>
                  <span class="badge badge-green">{owner}</span>
                  <div style="margin-top:8px; color:#e2e8f0; font-size:0.88rem;">{a.get('task','')}</div>
                </div>""", unsafe_allow_html=True)

        # Sentiment + churn detail
        st.markdown("---")
        col_s, col_c = st.columns(2, gap="large")
        with col_s:
            st.markdown('<div class="section-header">Sentiment Analysis</div>', unsafe_allow_html=True)
            st.markdown(f"""
            <div class="insight-card">
              <span class="badge" style="background:rgba(0,0,0,0.3); color:{sent_color}; 
                    border-color:{sent_color}44;">{sentiment_label}</span>
              <span class="badge badge-gray">Score: {sentiment_score:.2f}</span>
              <div style="margin-top:10px; color:#e2e8f0; font-size:0.85rem;">{sentiment.get('summary','')}</div>
            </div>""", unsafe_allow_html=True)

        with col_c:
            st.markdown('<div class="section-header">Churn Risk Assessment</div>', unsafe_allow_html=True)
            churn = insights.get("churn_risk", {})
            churn_pct = int(churn.get("score", 0) * 100)
            st.markdown(f"""
            <div class="insight-card">
              <span class="badge" style="background:rgba(0,0,0,0.3); color:{churn_color}; 
                    border-color:{churn_color}44;">Risk: {churn_pct}%</span>
              <span class="badge badge-gray">{churn.get('level','Unknown')}</span>
              <div class="churn-bar-container">
                <div class="churn-bar-fill" style="width:{churn_pct}%; background:{churn_color};"></div>
              </div>
              <div style="margin-top:10px; color:#e2e8f0; font-size:0.85rem;">{churn.get('reasoning','')}</div>
            </div>""", unsafe_allow_html=True)

        # Summary
        if insights.get("executive_summary"):
            st.markdown("---")
            st.markdown('<div class="section-header">Executive Summary</div>', unsafe_allow_html=True)
            st.markdown(f"""
            <div class="insight-card">
              <div style="color:#e2e8f0; font-size:0.9rem; line-height:1.7;">{insights['executive_summary']}</div>
            </div>""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 3 — CRM RECORD
# ─────────────────────────────────────────────────────────────────────────────
with tabs[2]:
    crm = st.session_state.get("crm_record")

    if not crm:
        st.info("Run the pipeline to generate a CRM record.")
    else:
        c1, c2 = st.columns([3, 2], gap="large")

        with c1:
            st.markdown('<div class="section-header">Structured CRM Record (JSON)</div>', unsafe_allow_html=True)
            st.markdown(f'<div class="crm-block">{json.dumps(crm, indent=2)}</div>', unsafe_allow_html=True)

        with c2:
            st.markdown('<div class="section-header">Salesforce Field Preview</div>', unsafe_allow_html=True)

            sf_fields = {
                "Account Name":     crm.get("account_name", ""),
                "Segment":          crm.get("segment", ""),
                "Interview Date":   crm.get("interview_date", ""),
                "Overall Sentiment":crm.get("overall_sentiment", ""),
                "Churn Risk Level": crm.get("churn_risk_level", ""),
                "# Pain Points":    crm.get("pain_point_count", 0),
                "# Feature Req.":   crm.get("feature_request_count", 0),
                "# Action Items":   crm.get("action_item_count", 0),
                "Priority Follow-up": crm.get("requires_priority_followup", False),
            }

            for field, value in sf_fields.items():
                icon = "✓" if value else "—"
                val_color = "#34d399" if value is True else ("#ef4444" if value is False else "#93c5fd")
                display_val = str(value) if not isinstance(value, bool) else ("Yes" if value else "No")
                st.markdown(f"""
                <div style="display:flex; justify-content:space-between; padding:8px 12px; 
                     background:#111120; border:1px solid #1e1e35; border-radius:6px; 
                     margin-bottom:6px;">
                  <span style="color:#6b7280; font-size:0.8rem; font-family:IBM Plex Mono,monospace;">{field}</span>
                  <span style="color:{val_color}; font-size:0.8rem; font-family:IBM Plex Mono,monospace; 
                        font-weight:500;">{display_val}</span>
                </div>""", unsafe_allow_html=True)

            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown('<div class="section-header">Mock Salesforce Sync</div>', unsafe_allow_html=True)

            if st.button("Simulate Salesforce Push →"):
                with st.spinner("Syncing to Salesforce…"):
                    time.sleep(1.8)
                mock_result = generate_mock_crm_sync(crm)
                st.success("✓ Record synced (mock)")
                st.json(mock_result)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 4 — DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────
with tabs[3]:
    insights = st.session_state.get("insights")

    # Load all processed records for aggregate view
    records_path = Path(__file__).parent.parent / "data" / "processed_records.json"
    all_records = []
    if records_path.exists():
        all_records = json.loads(records_path.read_text())

    # If we have a live result, prepend it
    if insights:
        all_records = [insights] + all_records

    if not all_records:
        st.info("Process at least one transcript to populate the dashboard. Sample data is available in the sidebar.")
        # Show a preview using demo data
        demo_path = Path(__file__).parent.parent / "data" / "demo_output.json"
        if demo_path.exists():
            all_records = [json.loads(demo_path.read_text())]
            st.caption("Showing demo data preview")

    if all_records:
        themes = analyze_themes(all_records)

        st.markdown('<div class="section-header">Aggregate Intelligence Dashboard</div>', unsafe_allow_html=True)

        # Top-line metrics
        total = len(all_records)
        avg_churn = sum(r.get("churn_risk", {}).get("score", 0) for r in all_records) / max(total, 1)
        total_pain = sum(len(r.get("pain_points", [])) for r in all_records)
        total_feat = sum(len(r.get("feature_requests", [])) for r in all_records)

        m1, m2, m3, m4 = st.columns(4)
        for col, num, label, color in [
            (m1, total,         "Interviews Processed", "#3b82f6"),
            (m2, total_pain,    "Total Pain Points",    "#ef4444"),
            (m3, total_feat,    "Feature Signals",      "#8b5cf6"),
            (m4, f"{int(avg_churn*100)}%", "Avg Churn Risk", "#f59e0b"),
        ]:
            with col:
                st.markdown(f"""
                <div class="metric-block">
                  <div class="metric-number" style="color:{color};">{num}</div>
                  <div class="metric-label">{label}</div>
                </div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        col_t, col_f = st.columns(2, gap="large")

        with col_t:
            st.markdown('<div class="section-header">Top Recurring Themes</div>', unsafe_allow_html=True)
            for i, theme in enumerate(themes.get("top_themes", [])[:6]):
                bar_pct = min(int(theme["frequency"] * 100), 100)
                theme_colors = ["#ef4444","#f59e0b","#3b82f6","#10b981","#8b5cf6","#ec4899"]
                color = theme_colors[i % len(theme_colors)]
                st.markdown(f"""
                <div style="margin-bottom:1rem;">
                  <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
                    <span style="color:#e2e8f0; font-size:0.85rem;">{theme['name']}</span>
                    <span style="color:#6b7280; font-size:0.75rem; font-family:IBM Plex Mono,monospace;">
                      {theme.get('count',1)} mentions
                    </span>
                  </div>
                  <div style="background:#1e1e35; border-radius:4px; height:5px;">
                    <div style="width:{bar_pct}%; background:{color}; height:100%; border-radius:4px;"></div>
                  </div>
                </div>""", unsafe_allow_html=True)

        with col_f:
            st.markdown('<div class="section-header">Top Feature Requests</div>', unsafe_allow_html=True)
            for feat in themes.get("top_features", [])[:5]:
                st.markdown(f"""
                <div class="insight-card card-feature" style="padding:0.9rem 1rem;">
                  <span class="badge badge-blue">{feat.get('priority','Medium')}</span>
                  <span style="color:#e2e8f0; font-size:0.85rem; display:block; margin-top:6px;">{feat.get('description','')}</span>
                </div>""", unsafe_allow_html=True)

        # Churn heat + sentiment breakdown
        st.markdown("---")
        col_ch, col_se = st.columns(2, gap="large")

        with col_ch:
            st.markdown('<div class="section-header">Churn Risk by Interview</div>', unsafe_allow_html=True)
            for r in all_records[:8]:
                churn_val = r.get("churn_risk", {}).get("score", 0)
                churn_pct = int(churn_val * 100)
                c_color   = "#10b981" if churn_val < 0.4 else ("#f59e0b" if churn_val < 0.7 else "#ef4444")
                cname = r.get("customer_name", r.get("metadata", {}).get("customer_name", "Unknown"))
                st.markdown(f"""
                <div style="display:flex; align-items:center; gap:12px; margin-bottom:8px;">
                  <div style="width:100px; color:#6b7280; font-size:0.75rem; 
                       font-family:IBM Plex Mono,monospace; flex-shrink:0; 
                       overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">{cname[:14]}</div>
                  <div style="flex:1; background:#1e1e35; border-radius:4px; height:8px;">
                    <div style="width:{churn_pct}%; background:{c_color}; height:100%; border-radius:4px;"></div>
                  </div>
                  <div style="width:36px; color:{c_color}; font-size:0.75rem; 
                       font-family:IBM Plex Mono,monospace; text-align:right;">{churn_pct}%</div>
                </div>""", unsafe_allow_html=True)

        with col_se:
            st.markdown('<div class="section-header">Sentiment Distribution</div>', unsafe_allow_html=True)
            sentiment_counts = {}
            for r in all_records:
                label = r.get("sentiment", {}).get("label", "Unknown")
                sentiment_counts[label] = sentiment_counts.get(label, 0) + 1

            sent_colors = {"Positive":"#10b981","Negative":"#ef4444","Neutral":"#6b7280","Mixed":"#f59e0b"}
            for label, count in sorted(sentiment_counts.items(), key=lambda x: -x[1]):
                pct = int((count / max(total, 1)) * 100)
                color = sent_colors.get(label, "#6b7280")
                st.markdown(f"""
                <div style="display:flex; align-items:center; gap:12px; margin-bottom:10px;">
                  <span class="badge" style="background:transparent; color:{color}; 
                        border-color:{color}44; width:70px; text-align:center;">{label}</span>
                  <div style="flex:1; background:#1e1e35; border-radius:4px; height:8px;">
                    <div style="width:{pct}%; background:{color}; height:100%; border-radius:4px;"></div>
                  </div>
                  <div style="width:36px; color:{color}; font-size:0.75rem; 
                       font-family:IBM Plex Mono,monospace; text-align:right;">{count}</div>
                </div>""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB 5 — EXPORT
# ─────────────────────────────────────────────────────────────────────────────
with tabs[4]:
    insights   = st.session_state.get("insights")
    crm_record = st.session_state.get("crm_record")

    if not insights:
        st.info("Run the pipeline to enable exports.")
    else:
        st.markdown('<div class="section-header">Export Options</div>', unsafe_allow_html=True)
        col_e1, col_e2, col_e3 = st.columns(3, gap="large")

        with col_e1:
            st.markdown("""
            <div class="insight-card">
              <div style="color:#3b82f6; font-size:1.1rem; margin-bottom:8px;">{ } JSON</div>
              <div style="color:#9ca3af; font-size:0.82rem;">Full structured insight record for downstream systems or databases.</div>
            </div>""", unsafe_allow_html=True)
            st.download_button(
                "Download insights.json",
                data=json.dumps(insights, indent=2),
                file_name="feedback_insights.json",
                mime="application/json",
                use_container_width=True,
            )

        with col_e2:
            st.markdown("""
            <div class="insight-card">
              <div style="color:#10b981; font-size:1.1rem; margin-bottom:8px;">⬛ CRM Record</div>
              <div style="color:#9ca3af; font-size:0.82rem;">Salesforce-compatible record with flattened fields for import.</div>
            </div>""", unsafe_allow_html=True)
            st.download_button(
                "Download crm_record.json",
                data=json.dumps(crm_record, indent=2),
                file_name="crm_record.json",
                mime="application/json",
                use_container_width=True,
            )

        with col_e3:
            # Build markdown summary
            md_lines = [
                f"# Feedback Intelligence Report",
                f"**Customer:** {crm_record.get('account_name', 'N/A')}  ",
                f"**Date:** {crm_record.get('interview_date', 'N/A')}  ",
                f"**Sentiment:** {crm_record.get('overall_sentiment', 'N/A')}  ",
                f"**Churn Risk:** {crm_record.get('churn_risk_level', 'N/A')}  \n",
                "## Executive Summary",
                insights.get("executive_summary", ""),
                "\n## Pain Points",
            ]
            for p in insights.get("pain_points", []):
                md_lines.append(f"- **[{p.get('severity','').upper()}]** {p.get('description','')}")
            md_lines.append("\n## Feature Requests")
            pri_map = {"High": "1", "Medium": "2", "Low": "3"}
            for f in insights.get("feature_requests", []):
                pri_n = pri_map.get(f.get('priority','Medium').capitalize(), '2')
                md_lines.append(f"- **[P{pri_n}]** {f.get('description','')}")
            md_lines.append("\n## Action Items")
            for a in insights.get("action_items", []):
                md_lines.append(f"- [{a.get('owner','')}] {a.get('task','')}")
            md_content = "\n".join(md_lines)

            st.markdown("""
            <div class="insight-card">
              <div style="color:#8b5cf6; font-size:1.1rem; margin-bottom:8px;">📄 Markdown</div>
              <div style="color:#9ca3af; font-size:0.82rem;">Human-readable report for Notion, Confluence, or email.</div>
            </div>""", unsafe_allow_html=True)
            st.download_button(
                "Download report.md",
                data=md_content,
                file_name="feedback_report.md",
                mime="text/markdown",
                use_container_width=True,
            )
